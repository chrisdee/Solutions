$ServiceUrl = 'https://api.admin.microsoftonline.com/shdtenantcommunications.svc'

$SessionTypeName = 'O365ServiceCommunications.Session'
$EventTypeName   = 'O365ServiceCommunications.Event'
$TenantEventTypeName = 'O365ServiceCommunications.TenantEvent'
$TenantServiceInfoTypeName = 'O365ServiceCommunications.TenantServiceInfo'
$ServiceInfoTypeName   = 'O365ServiceCommunications.ServiceInfo'
