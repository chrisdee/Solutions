---
external help file: O365ServiceCommunications-help.xml
online version: https://msdn.microsoft.com/en-us/library/office/dn776043.aspx
schema: 2.0.0
---

# Get-SCTenantEvent

## SYNOPSIS
{{Fill in the Synopsis}}

## SYNTAX

```
Get-SCTenantEvent [-SCSession] <Object> [[-EventTypes] <String[]>] [-Domains] <Object> [[-PastDays] <Int32>]
```

## DESCRIPTION
{{Fill in the Description}}

## EXAMPLES

### Example 1
```
PS C:\> {{ Add example code here }}
```

{{ Add example description here }}

## PARAMETERS

### -Domains
{{Fill Domains Description}}

```yaml
Type: Object
Parameter Sets: (All)
Aliases: 

Required: True
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -EventTypes
{{Fill EventTypes Description}}

```yaml
Type: String[]
Parameter Sets: (All)
Aliases: 
Accepted values: Incident, Maintenance, Message

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -PastDays
{{Fill PastDays Description}}

```yaml
Type: Int32
Parameter Sets: (All)
Aliases: 

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SCSession
{{Fill SCSession Description}}

```yaml
Type: Object
Parameter Sets: (All)
Aliases: 

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

## INPUTS

### None


## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS

