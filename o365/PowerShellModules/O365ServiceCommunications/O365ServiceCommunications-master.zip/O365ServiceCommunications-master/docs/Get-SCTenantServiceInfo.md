---
external help file: O365ServiceCommunications-help.xml
online version: https://msdn.microsoft.com/en-us/library/office/dn776043.aspx
schema: 2.0.0
---

# Get-SCTenantServiceInfo

## SYNOPSIS
{{Fill in the Synopsis}}

## SYNTAX

```
Get-SCTenantServiceInfo [-SCSession] <Object> [-Domains] <String[]>
```

## DESCRIPTION
{{Fill in the Description}}

## EXAMPLES

### Example 1
```
PS C:\> {{ Add example code here }}
```

{{ Add example description here }}

## PARAMETERS

### -Domains
{{Fill Domains Description}}

```yaml
Type: String[]
Parameter Sets: (All)
Aliases: 

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SCSession
{{Fill SCSession Description}}

```yaml
Type: Object
Parameter Sets: (All)
Aliases: 

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

## INPUTS

### None


## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS

