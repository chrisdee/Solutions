# PowerShell-SPOCmdlets
A Microsoft SharePoint Online Services Module for Windows PowerShell developed by Gary Lapointe.
