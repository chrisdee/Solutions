$global:FunctionHelpTestExceptions = @(
    "TabExpansion2"
)
